module.exports = {
  'pre-commit': 'npx lint-staged',
};
